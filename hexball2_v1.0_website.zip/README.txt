핵스볼 메니저 2 — v1.0 웹사이트 파일

[구성]
index.html             게임 본체 (이 파일 하나로도 실행됨)
manifest.webmanifest   폰 홈 화면에 앱처럼 설치하기 위한 설정
sw.js                  한 번 접속하면 오프라인에서도 실행되게 하는 캐시
icon-*.png             앱 아이콘

[가장 쉬운 배포 — Netlify Drop (무료, 1분)]
1. https://app.netlify.com/drop 접속
2. 이 폴더(압축 푼 폴더)를 통째로 끌어다 놓기
3. 나온 주소(https://xxxx.netlify.app)를 공유하면 끝

[GitHub Pages]
1. GitHub에 새 저장소 만들기 → 이 파일들 업로드
2. Settings → Pages → Branch: main / root 선택 → Save
3. https://아이디.github.io/저장소이름/ 으로 접속

[폰에 앱처럼 설치]
- 안드로이드(크롬): 사이트 접속 → 메뉴 ⋮ → "홈 화면에 추가" / "앱 설치"
- 아이폰(사파리): 사이트 접속 → 공유 버튼 → "홈 화면에 추가"

[참고]
- 저장 데이터는 각 기기 브라우저에 저장돼요 (기기끼리 공유 안 됨).
- 주소(도메인)가 바뀌면 저장도 따로예요. 한 주소로 계속 쓰세요.
- 업데이트할 때는 index.html을 바꾸고 sw.js의 CACHE 이름(hexball2-v1.0)을 v1.1 등으로 바꿔 올리세요.
